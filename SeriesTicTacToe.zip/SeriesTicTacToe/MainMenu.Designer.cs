﻿namespace SeriesTicTacToe
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.btPyramic = new Guna.UI2.WinForms.Guna2TileButton();
            this.bt5Multi5 = new Guna.UI2.WinForms.Guna2TileButton();
            this.btMiscre = new Guna.UI2.WinForms.Guna2TileButton();
            this.bt4multi4 = new Guna.UI2.WinForms.Guna2TileButton();
            this.btFourInRow = new Guna.UI2.WinForms.Guna2TileButton();
            this.btNumerical = new Guna.UI2.WinForms.Guna2TileButton();
            this.btWord = new Guna.UI2.WinForms.Guna2TileButton();
            this.guna2TileButton8 = new Guna.UI2.WinForms.Guna2TileButton();
            this.btExist = new Guna.UI2.WinForms.Guna2TileButton();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btPyramic
            // 
            this.btPyramic.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btPyramic.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btPyramic.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btPyramic.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btPyramic.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btPyramic.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold);
            this.btPyramic.ForeColor = System.Drawing.Color.Black;
            this.btPyramic.Location = new System.Drawing.Point(150, 102);
            this.btPyramic.Name = "btPyramic";
            this.btPyramic.Size = new System.Drawing.Size(220, 32);
            this.btPyramic.TabIndex = 0;
            this.btPyramic.Text = "Pyramic Tic-Tac-Toe";
            this.btPyramic.Click += new System.EventHandler(this.btPyramic_Click);
            // 
            // bt5Multi5
            // 
            this.bt5Multi5.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bt5Multi5.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bt5Multi5.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bt5Multi5.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bt5Multi5.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.bt5Multi5.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt5Multi5.ForeColor = System.Drawing.Color.Black;
            this.bt5Multi5.Location = new System.Drawing.Point(150, 157);
            this.bt5Multi5.Name = "bt5Multi5";
            this.bt5Multi5.Size = new System.Drawing.Size(220, 32);
            this.bt5Multi5.TabIndex = 1;
            this.bt5Multi5.Text = "5 x 5 Tic Tac Toe";
            // 
            // btMiscre
            // 
            this.btMiscre.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btMiscre.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btMiscre.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btMiscre.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btMiscre.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btMiscre.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btMiscre.ForeColor = System.Drawing.Color.Black;
            this.btMiscre.Location = new System.Drawing.Point(150, 211);
            this.btMiscre.Name = "btMiscre";
            this.btMiscre.Size = new System.Drawing.Size(220, 32);
            this.btMiscre.TabIndex = 2;
            this.btMiscre.Text = "Misere Tic Tac Toe";
            // 
            // bt4multi4
            // 
            this.bt4multi4.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.bt4multi4.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.bt4multi4.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.bt4multi4.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.bt4multi4.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.bt4multi4.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt4multi4.ForeColor = System.Drawing.Color.Black;
            this.bt4multi4.Location = new System.Drawing.Point(150, 271);
            this.bt4multi4.Name = "bt4multi4";
            this.bt4multi4.Size = new System.Drawing.Size(220, 32);
            this.bt4multi4.TabIndex = 3;
            this.bt4multi4.Text = "4 x 4 Tic-Tac-Toe";
            // 
            // btFourInRow
            // 
            this.btFourInRow.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btFourInRow.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btFourInRow.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btFourInRow.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btFourInRow.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btFourInRow.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btFourInRow.ForeColor = System.Drawing.Color.Black;
            this.btFourInRow.Location = new System.Drawing.Point(418, 102);
            this.btFourInRow.Name = "btFourInRow";
            this.btFourInRow.Size = new System.Drawing.Size(220, 32);
            this.btFourInRow.TabIndex = 5;
            this.btFourInRow.Text = "Four-in-a-row";
            // 
            // btNumerical
            // 
            this.btNumerical.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btNumerical.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btNumerical.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btNumerical.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btNumerical.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btNumerical.Font = new System.Drawing.Font("Elephant", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btNumerical.ForeColor = System.Drawing.Color.Black;
            this.btNumerical.Location = new System.Drawing.Point(418, 157);
            this.btNumerical.Name = "btNumerical";
            this.btNumerical.Size = new System.Drawing.Size(220, 32);
            this.btNumerical.TabIndex = 6;
            this.btNumerical.Text = "Numerical Tic-Tac-Toe";
            // 
            // btWord
            // 
            this.btWord.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btWord.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btWord.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btWord.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btWord.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btWord.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btWord.ForeColor = System.Drawing.Color.Black;
            this.btWord.Location = new System.Drawing.Point(418, 211);
            this.btWord.Name = "btWord";
            this.btWord.Size = new System.Drawing.Size(220, 32);
            this.btWord.TabIndex = 7;
            this.btWord.Text = "Word Tic-tac-toe";
            // 
            // guna2TileButton8
            // 
            this.guna2TileButton8.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton8.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.guna2TileButton8.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.guna2TileButton8.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.guna2TileButton8.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.guna2TileButton8.Font = new System.Drawing.Font("Elephant", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guna2TileButton8.ForeColor = System.Drawing.Color.Black;
            this.guna2TileButton8.Location = new System.Drawing.Point(418, 271);
            this.guna2TileButton8.Name = "guna2TileButton8";
            this.guna2TileButton8.Size = new System.Drawing.Size(220, 32);
            this.guna2TileButton8.TabIndex = 7;
            this.guna2TileButton8.Text = "Ultimate Tic Tac Toe";
            // 
            // btExist
            // 
            this.btExist.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btExist.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btExist.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btExist.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btExist.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(212)))), ((int)(((byte)(92)))), ((int)(((byte)(246)))));
            this.btExist.Font = new System.Drawing.Font("Broadway", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btExist.ForeColor = System.Drawing.Color.Black;
            this.btExist.Location = new System.Drawing.Point(150, 333);
            this.btExist.Name = "btExist";
            this.btExist.Size = new System.Drawing.Size(115, 32);
            this.btExist.TabIndex = 8;
            this.btExist.Text = "Exist";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Stencil", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(178, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(437, 32);
            this.label1.TabIndex = 9;
            this.label1.Text = "Welcome to Tic-Tac-Toe Series";
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(785, 439);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btExist);
            this.Controls.Add(this.guna2TileButton8);
            this.Controls.Add(this.btWord);
            this.Controls.Add(this.btNumerical);
            this.Controls.Add(this.btFourInRow);
            this.Controls.Add(this.bt4multi4);
            this.Controls.Add(this.btMiscre);
            this.Controls.Add(this.bt5Multi5);
            this.Controls.Add(this.btPyramic);
            this.Name = "MainMenu";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2TileButton btPyramic;
        private Guna.UI2.WinForms.Guna2TileButton bt5Multi5;
        private Guna.UI2.WinForms.Guna2TileButton btMiscre;
        private Guna.UI2.WinForms.Guna2TileButton bt4multi4;
        private Guna.UI2.WinForms.Guna2TileButton btFourInRow;
        private Guna.UI2.WinForms.Guna2TileButton btNumerical;
        private Guna.UI2.WinForms.Guna2TileButton btWord;
        private Guna.UI2.WinForms.Guna2TileButton guna2TileButton8;
        private Guna.UI2.WinForms.Guna2TileButton btExist;
        private System.Windows.Forms.Label label1;
    }
}

