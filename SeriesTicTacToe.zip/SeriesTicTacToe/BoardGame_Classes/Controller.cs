﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BoardGame_Classes
{

    using System;

    public class Controller
    {
        private static Board<char> CreateBoard(int selectedBoard)
        {
            switch (selectedBoard)
            {
                case 1:
                    return new TicTacToeBoard();


                default:
                    break;
            }
            return null;
        }

        public static Player<char> CreateHumanPlayer(int gameNumber, string playerName, char playerSymbol)
        {
            switch (gameNumber)
            {
                case 1:
                    return new TicTacToePlayer(playerName, playerSymbol);


                default:
                    break;
            }
            return null;
        }

        public static Player<char> CreateComputerPlayer(int gameNumber, char playerSymbol)
        {
            switch (gameNumber)
            {
                case 1:
                    return new TicTacToeRandomPlayer(playerSymbol);


                default:

                    break;
            }
            return null;
        }
        private static bool IsValidMove_Payramic(int move_x, int move_y)
        {
            if ((move_x == 0 && move_y == 0) || (move_x == 0 && move_y == 1) || (move_x == 0 && move_y == 2) || (move_x == 0 && move_y == 3) 
                || (move_x == 0 && move_y == 4) || (move_x == 1 && move_y == 1) || (move_x == 1 && move_y == 2) || (move_x == 1 && move_y == 3) 
                || (move_x == 2 && move_y == 2))
            {  return true; }
            return false;
  }
        
        public static void generateRandomMove(ref int  move_x ,ref int  move_y,int dimension,int row , int column)
        {
            Random _random = new Random();
            do
            {
                move_x = _random.Next(0, dimension);// generate number between 0 and 4
                move_y = _random.Next(0, dimension);
            } while (!IsValidMove_Payramic(move_x,move_y));
            
        }

        //private static string SelectGameName(int gameNumber)
        //{
        //    return gameNumber switch
        //    {
        //        1 => "Pyramid Tic-Tac-Toe",
        //        _ => "Unknown Game"
        //    };
        //}

        //private static void SelectNameAndType(string gameName, char playerSymbol, out Player<char> player, int gameNumber)
        //{
        //    Console.WriteLine($"Welcome to {gameName}.");
        //    Console.Write($"Enter Player {playerSymbol} name: ");
        //    string playerName = Console.ReadLine();
        //    Console.WriteLine("Choose Player type:\n1. Human\n2. Random Computer");
        //    int choice = int.Parse(Console.ReadLine());

        //    player = choice == 1
        //        ? CreateHumanPlayer(gameNumber, playerName, playerSymbol)
        //        : CreateComputerPlayer(gameNumber, playerSymbol);
        //}
        public static GameManager<char> createGameManager(int gameNumber, Player<char>[] players)
        {
            var board = CreateBoard(gameNumber);

            Player<char>[] _players = players;

            var gameManager = new GameManager<char>(board, players);
            
            return gameManager;
        }
        
    }

}